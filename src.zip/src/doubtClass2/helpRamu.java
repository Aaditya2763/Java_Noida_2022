package doubtClass2;

import java.util.Scanner;

public class helpRamu {
public static void main(String[] args) {
	Scanner scn=new Scanner(System.in);
	int t =scn.nextInt();
	while(t>0) {
		int rn=scn.nextInt();
	int cn=scn.nextInt();
		int[]ride_rckshaw=new int[rn];
		int[]ride_cab= new int [cn];
	}
}
}
