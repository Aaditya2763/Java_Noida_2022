package Lecture_6;

public class PrimitiveDatatype {

	public static void main(String[] args) {
		
		//Data types in java
		
//		 1byte=bit
		
//		1. float = 4 byte
//		2.double =2.758 (8 byte)
//		3.boolean = true or false (1 bit)
//		4.char  = 's' contains only one character
//		
//		
//		
//		5.byte
//		6.short
//		7.int 
//		8.long
		
		
//		Number System 
		
//		Binary =Base 2 (Number bannane ke liye (0-1) ka number use hota hai)
//		Decimal =Base 10 (Number bannane ke liye (0-9) ka number use hota hai)
//		octal =Base 8 (Number bannane ke liye (0-7) ka number use hota hai)
//		
		int a=014;
		System.out.println(a);
		
//		77\\
		System.out.println();
	
	
		
	}
}
