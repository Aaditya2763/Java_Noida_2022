package LEcture_13_Sorting;

public class Kth_value_Self {
	public static void main(String[] args) {
		int num = 87;
		int k = 3;
		Kth_Value(num, k);
	}

	public static void Kth_Value(int num, int k) {

		
}
}