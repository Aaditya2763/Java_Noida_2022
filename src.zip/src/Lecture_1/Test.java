package Lecture_1;

public class Test {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int x=2%2;
		System.out.println(x);

	}

}
