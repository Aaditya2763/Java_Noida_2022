package Lecture_1;

public class SimpleInterest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int p=1000;
		int rate=5;
		int time=2;
		 int si =(p*rate*time)/100;
		 System.out.println("Simple interset is" + si);

	}

}
