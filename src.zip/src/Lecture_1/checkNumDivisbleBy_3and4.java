package Lecture_1;

public class checkNumDivisbleBy_3and4 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int a=3;
		int b=4;
		int Number=15;
		if (Number%a==0 && Number%b==0) {
			System.out.println("Number is Divisible by 3 and 4");
		}
		else {
			System.out.println("Number is not  Divisible by 3 and 4");
		}

	}

}
