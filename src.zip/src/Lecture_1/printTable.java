package Lecture_1;

public class printTable {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		int num= 6;
		for(int i=1;i<=10;i++) {
			
			System.out.println(num+" * "+i+" = "+num*i);
		}

	}

}
