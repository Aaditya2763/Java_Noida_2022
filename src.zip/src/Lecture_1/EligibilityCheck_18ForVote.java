package Lecture_1;

public class EligibilityCheck_18ForVote {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int age=36;
		if(age>=18) {
			System.out.println("You are eligible to vote");
		}
		else {
			System.out.println("You are not eligible to vote");
		}

	}

}
