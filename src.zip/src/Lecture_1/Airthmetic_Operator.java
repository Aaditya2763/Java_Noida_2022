
package Lecture_1;

public class Airthmetic_Operator {
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		 int a=8;
		 int b=11;
		 int c=a+b;
		 System.out.println(c);
		 System.out.println(a+b);
	}
	public static void add() {
		
	}

}
