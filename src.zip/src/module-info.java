/**
 * 
 */
/**
 * @author Aaditya Singh
 *
 */
module Crux_Np_Oct_2022 {
	
}