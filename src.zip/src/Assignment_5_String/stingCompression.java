package Assignment_5_String;

public class stingCompression {
public static void main(String[] args) {
	String str="aaabbcccsgfff";
}
public static void countString(String str) {
	int count=0;
	
}
}
