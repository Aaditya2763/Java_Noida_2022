package Assignment_5_String;

public class maximumFrequency {
public static void main(String[] args) {
	String str="aaabacb";
	maxCount(str);
}
public static void maxCount(String str) {
int len=str.length();
int []count =new int[len];
int c=0;

}
}
