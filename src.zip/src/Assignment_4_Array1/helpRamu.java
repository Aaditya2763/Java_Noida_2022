package Assignment_4_Array1;

public class helpRamu {
public static void main(String[] args) {
	int var =1<<4;
	System.out.println(var);
}
}