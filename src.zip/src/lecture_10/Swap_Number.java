package lecture_10;

public class Swap_Number {
public static void main(String[] args) {
int a=5;
int b=7;
int temp=a;


}
}
